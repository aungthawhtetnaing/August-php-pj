 <footer class="footer text-faded text-center py-3">
    <div class="container">
      <p class="m-0 large">Copyright &copy; August 2020</p>
    </div>
  </footer>